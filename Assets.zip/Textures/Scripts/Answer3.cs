﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Answer3 : MonoBehaviour
{
    private Color c2;
    // Start is called before the first frame update
    void Start()
    {
        c2 = transform.GetComponent<SpriteRenderer>().color;
        c2.a = 0f;
        transform.GetComponent<SpriteRenderer>().color = c2;
    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("Answer");
        Destroy(collision.gameObject);
        c2.a = 255f;
        transform.GetComponent<SpriteRenderer>().color = c2;
        StartCoroutine(WaitAndPrint(4F));//两秒后执行WaitAndPrint()方法
    }

    IEnumerator WaitAndPrint(float waitTime)
    {
        yield return new WaitForSeconds(waitTime);
        //等待之后执行的动作  
        c2.a = 0f;
        transform.GetComponent<SpriteRenderer>().color = c2;
    }
}
