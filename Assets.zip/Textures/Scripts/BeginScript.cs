﻿using UnityEngine;
using System.Collections;

public class BeginScript : MonoBehaviour {

    private GUISkin GUISkin;

    void Start()
    {
        // Load a skin for the buttons
        GUISkin = Resources.Load("GUISkin") as GUISkin;
    }


    void OnGUI()
    {
        const int buttonWidth = 60;
        const int buttonHeight = 35;

        // Set the skin to use
        GUI.skin = GUISkin;


        // Draw a button to start the game
        if (GUI.Button(new Rect(
                Screen.width / 2 - (buttonWidth / 2),
                (4 * Screen.height / 5) - (buttonHeight / 2),
             buttonWidth,
                buttonHeight
                ), "Start!"))
        {
            // On Click, load the first level.
            // "Stage1" is the name of the first scene we created.
            Application.LoadLevel("sky");
        }
    }
}
