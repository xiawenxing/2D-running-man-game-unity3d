﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AskingScript : MonoBehaviour
{
    void OnTriggerEnter2D(Collider2D collision)
    {
    
//        Application.LoadLevel("Game");
    }
}
