﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Answer1 : MonoBehaviour
{
    private Color c;
    // Start is called before the first frame update
    void Start()
    {
        c=transform.GetComponent<SpriteRenderer> ().color;
        c.a = 0f;
        transform.GetComponent<SpriteRenderer>().color = c;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("Answer");
        Destroy(collision.gameObject);
        c.a = 255f;
        transform.GetComponent<SpriteRenderer>().color = c;
        StartCoroutine(WaitAndPrint(4F));//两秒后执行WaitAndPrint()方法
    }

    IEnumerator WaitAndPrint(float waitTime)
    {
        yield return new WaitForSeconds(waitTime);
        //等待之后执行的动作  
        c.a = 0f;
        transform.GetComponent<SpriteRenderer>().color = c;
    }
}
