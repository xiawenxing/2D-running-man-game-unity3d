﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Answer2 : MonoBehaviour
{
    private Color c1;
    // Start is called before the first frame update
    void Start()
    {
        c1 = transform.GetComponent<SpriteRenderer>().color;
        c1.a = 0f;
        transform.GetComponent<SpriteRenderer>().color = c1;
    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("Answer");
        Destroy(collision.gameObject);
        c1.a = 255f;
        transform.GetComponent<SpriteRenderer>().color = c1;
        StartCoroutine(WaitAndPrint(4F));//两秒后执行WaitAndPrint()方法
    }

    IEnumerator WaitAndPrint(float waitTime)
    {
        yield return new WaitForSeconds(waitTime);
        //等待之后执行的动作  
        c1.a = 0f;
        transform.GetComponent<SpriteRenderer>().color = c1;
    }
}