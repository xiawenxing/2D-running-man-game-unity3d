﻿using UnityEngine;
using System.Collections;

public class flyboatScript : MonoBehaviour {

    // Use this for initialization
    void Start()
    {
        print("启动!");
    }

    public Vector2 speed = new Vector2(10, 10);
    public Vector2 movement;
    public Rigidbody2D rigidbodyComponent;


    // Update is called once per frame
    void Update()
    {
        float inputX = Input.GetAxis("Horizontal");
        float inputY = Input.GetAxis("Vertical");

        movement = new Vector2(
            speed.x * inputX,
            speed.y * inputY
            );
    }

    void FixedUpdate()
    {
        if (rigidbodyComponent == null)
            rigidbodyComponent = GetComponent<Rigidbody2D>();

        rigidbodyComponent.velocity = movement;
    }

    void Awake()
    {
        print("我是构造函数");
    }
}
