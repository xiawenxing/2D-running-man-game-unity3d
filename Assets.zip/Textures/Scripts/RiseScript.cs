﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RiseScript : MonoBehaviour
{
    // 1 - Designer variables
    // Object speed 
    public Vector2 speed = new Vector2(7, 7);
    private float jumpForce;  //跳跃的力
    private Rigidbody2D rig;   //刚体
    // Moving direction 
    public Vector2 direction = new Vector2(0, 1);
    private Vector2 movement;
    void Start()
    {
        rig = GetComponent<Rigidbody2D>();   //获取主角刚体组件

        jumpForce = 7f;   //跳跃力的大小

    }
    void Update()
    {
       
    }
    void OnTriggerEnter2D(Collider2D collision)
    {
        movement = new Vector2(0, jumpForce);
    }
    void FixedUpdate()
    {
        // Apply movement to the rigidbody 
        GetComponent<Rigidbody2D>().velocity = movement;
    }
}
